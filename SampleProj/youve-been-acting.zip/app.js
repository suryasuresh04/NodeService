/* var express = require("express")

var app = express()

//const speech = require('./speech.1.0.0.js');

app.get("/",function(req,res){
    res.send("<h1>hello<h1>")  
})

var server = app.listen(3000,function(){
	console.log("Lisening in port 3000");
})
 */
 
var fs = require('fs');
var bing = require('bingspeech-api-client');

const LUISClient = require('luis-sdk');

var audioStream = fs.createReadStream('whatstheweatherlike.wav'); 

var subscriptionKey = '5cb2a3f59d724165958d473025c8a31f';




var client = new bing.BingSpeechClient(subscriptionKey);
client.recognizeStream(audioStream)
	  .then(response => LuisCall(response.results[0].name));
      /* .then(response => console.log(response.results[0].name)); */
	  
var LuisCall = function (text) {
	
	var APPID = '605ae73d-d349-41d3-a639-87c48a3f238f';
var APPKEY = 'f70081ac7af946bd8de16c657259f9fd';
	
/* 	console.log(text);
	console.log(APPID);
	console.log(APPKEY); */
	
	var LUISclient = LUISClient({
  appId: APPID,
  appKey: APPKEY,
  verbose: true
});
	
	LUISclient.predict(text, {

  //On success of prediction
  onSuccess: function (response) {
    printOnSuccess(response);
  },

  //On failure of prediction
  onFailure: function (err) {
    console.error(err);
  }
});
	
}

var printOnSuccess = function (response) {
	console.log(response);
	console.log("-------------------");
  console.log("Query: " + response.query);
  console.log("Top Intent: " + response.topScoringIntent.intent);
  console.log("Entities:");
  for (var i = 1; i <= response.entities.length; i++) {
    console.log(i + "- " + response.entities[i-1].entity);
  }
  if (typeof response.dialog !== "undefined" && response.dialog !== null) {
    console.log("Dialog Status: " + response.dialog.status);
    if(!response.dialog.isFinished()) {
      console.log("Dialog Parameter Name: " + response.dialog.parameterName);
      console.log("Dialog Prompt: " + response.dialog.prompt);
    }
  }
};